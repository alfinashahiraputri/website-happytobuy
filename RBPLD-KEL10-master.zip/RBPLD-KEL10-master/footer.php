<div style="height: 100px;background-color: rgb(242, 242, 242)">
	<div class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4" >
				<img src="/assets/img/icon/wa.png" style="width: 100px;margin-top: -8%;margin-left: 21%">
				<img src="/assets/img/icon/line.png" style="width: 45px;margin-top: -8%;margin-left: -7%">
				<img src="/assets/img/icon/ig.png" style="width: 50px;margin-top: -8%">
			</div>
			<div class="col-md-4"></div>
		</div>
	</div>
</div>
<div style="height: 55px;background-color: black">
  <p class="text-center" style="color:#eaeaea;padding-top: 1%">Copyright 2020</p>
</div>